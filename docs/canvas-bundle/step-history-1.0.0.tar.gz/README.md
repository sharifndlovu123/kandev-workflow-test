# Task Step History

Shows the workflow's full step sequence, visits-per-step counts, and a simplified chronological transition history for this task.

Build and publish the retained canvas files.
